package servicodefuncionario.model;

public enum TipoFuncionario {
    ADMIN,
    FUNC
}