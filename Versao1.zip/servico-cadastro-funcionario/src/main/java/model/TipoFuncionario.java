package model;

public enum TipoFuncionario {
    ADMIN,
    FUNC
}