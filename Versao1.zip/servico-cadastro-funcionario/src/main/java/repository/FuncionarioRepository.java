package repository;

import model.Funcionario;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FuncionarioRepository extends MongoRepository<Funcionario, String> {
    // Falta adicionar alguns métodos caso seja necessário
}
