package service;

import model.Funcionario;
import java.util.List;

public interface FuncionarioService {
    List<Funcionario> listarFuncionarios();
    Funcionario buscarFuncionarioPorId(String id);
    Funcionario adicionarFuncionario(Funcionario funcionario);
    Funcionario atualizarFuncionario(String id, Funcionario funcionario);
    void deletarFuncionario(String id);
}